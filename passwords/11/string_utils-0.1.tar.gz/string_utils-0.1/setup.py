from setuptools import setup

setup(
    name='string_utils',
    version='0.1',
    description='Few string functions',
    packages=['string_utils']
)