from setuptools import setup

setup(
    name='password_validators',
    version='0.1',
    description='Collection of password validators',
    author='Szymurai',
    packages=['password_validators'],
    install_requires=['requests']
)
